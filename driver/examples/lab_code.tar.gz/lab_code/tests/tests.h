#ifndef CHECK_TEST_SUITE_H
#define CHECK_TEST_SUITE_H

#include <string.h>
#include <check.h>

Suite *create_digest_suite (void);
Suite *create_list_suite (void);

#endif /* CHECK_TEST_SUITE_H */
