#!/bin/sh
#start alphafilter
#note: before using this script execute rene's script to setup iptables so that the two comm. hosts do not overgo this middlebox
./alphafilter
