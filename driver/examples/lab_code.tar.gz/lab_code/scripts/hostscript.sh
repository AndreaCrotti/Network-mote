#!/bin/sh
#run alpha
./alpha &
#start iperf
./iperf -s

