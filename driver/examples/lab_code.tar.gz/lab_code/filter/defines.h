// vim:encoding=latin1:foldmethod=marker:foldmarker=//[[,//]]
/*
 * Copyright (c) 2009, Distributed Systems Group, RWTH Aachen
 * All rights reserved.
 */

#ifndef __DEFINES_H__
#define __DEFINES_H__

#define HASHSIZE 20
#define print_error(a...) fprintf(stderr, ## a)

#endif // __DEFINES_H__
